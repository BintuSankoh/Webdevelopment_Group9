﻿import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const SUPABASE_URL = 'https://tqrngdjuuhsxvploruwd.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRxcm5nZGp1dWhzeHZwbG9ydXdkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4OTYzNTksImV4cCI6MjA5MTQ3MjM1OX0.W8LZRV71_cSny4mwOS12--iPRv3wfARBV1lNU_Ts45Y';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const TABLE_NAME = 'student_enrolment';

export async function fetchStudents() {
  const { data, error } = await supabase.from(TABLE_NAME).select('*');
  if (error) {
    console.error('Error fetching students:', error);
    throw error;
  }
  return data || [];
}

export async function addStudent(student) {
  const { data, error } = await supabase.from(TABLE_NAME).insert([student]);
  if (error) {
    console.error('Error adding student:', error);
    throw error;
  }
  return data;
}

export async function deleteStudent(studentId) {
  const { data, error } = await supabase.from(TABLE_NAME).delete().eq('id', studentId);
  if (error) {
    console.error('Error deleting student:', error);
    throw error;
  }
  return data;
}

export async function updateStudent(studentId, updates) {
  const { data, error } = await supabase.from(TABLE_NAME).update(updates).eq('id', studentId);
  if (error) {
    console.error('Error updating student:', error);
    throw error;
  }
  return data;
}
